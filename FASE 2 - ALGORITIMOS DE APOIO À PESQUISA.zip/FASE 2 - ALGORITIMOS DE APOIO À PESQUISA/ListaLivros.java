// Classe que implementa uma lista sequencial de livros
class ListaLivros {
    private Livro[] livros;
    private int count;

    public ListaLivros() {
        livros = new Livro[100]; // Capacidade inicial
        count = 0;
    }

    public boolean isEmpty() {
        return count == 0;  // Retorna true se não houver livros cadastrados
    }


    public void adicionar(Livro livro) {
        if (count < livros.length) {
            livros[count] = livro;
            count++;
        } else {
            System.out.println("Capacidade máxima alcançada.");
        }
    }

    public void listarLivros() {
        if (count == 0) {
            System.out.println("Nenhum livro cadastrado.");
            return;
        }
            for (int i = 0; i < count; i++) {
        System.out.println(livros[i]); // A chamada para `toString` irá formatar os dados corretamente
    }}
    
    public void buscarLivro(String criterio) {
    if (isEmpty()) {
        System.out.println("Nenhum livro cadastrado para buscar.");
        return;
    }
        boolean encontrado = false;
    for (int i = 0; i < count; i++) {
        if (livros[i].titulo.equalsIgnoreCase(criterio) || 
            livros[i].autor.equalsIgnoreCase(criterio) || 
            livros[i].tema.equalsIgnoreCase(criterio)) {
            System.out.println("Livro encontrado: " + livros[i]);
            encontrado = true;
        }
    }
    if (!encontrado) {
        System.out.println("Nenhum livro encontrado com o critério: " + criterio);
    }
}


    

    public void ordenarPorTitulo() {
    if (isEmpty()) {
        System.out.println("Nenhum livro cadastrado para ordenar por título.");
        return;
    }
        bubbleSort("titulo");
    }

    public void ordenarPorAutor() {
    if (isEmpty()) {
        System.out.println("Nenhum livro cadastrado para ordenar por autor.");
        return;
    }
        bubbleSort("autor");
    }


    private void bubbleSort(String criterio) {
        for (int i = 0; i < count - 1; i++) {
            // Comparação com base no critério (título ou autor)
            for (int j = 0; j < count - i - 1; j++) {
                if (criterio.equals("titulo") && livros[j].titulo.compareTo(livros[j + 1].titulo) > 0) {
                    // Troca livros[j] e livros[j + 1]
                    // Troca se o título atual for "maior" que o próximo
                    Livro temp = livros[j];
                    livros[j] = livros[j + 1];
                    livros[j + 1] = temp;
                } else if (criterio.equals("autor") && livros[j].autor.compareTo(livros[j + 1].autor) > 0) {
                    // Troca livros[j] e livros[j + 1]
                    // Troca se o autor atual for "maior" que o próximo
                    Livro temp = livros[j];
                    livros[j] = livros[j + 1];
                    livros[j + 1] = temp;
                }
            }
        }
    }
}

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ListaLivros listaLivros = new ListaLivros();
        ArvoreBinaria arvoreTemas = new ArvoreBinaria();
        Scanner scanner = new Scanner(System.in);
        
        int opcao;
        do {
            System.out.println("\nMenu:");
            System.out.println("1. Adicionar Livro");
            System.out.println("2. Listar Livros");
            System.out.println("3. Ordenar Livros por Título");
            System.out.println("4. Ordenar Livros por Autor");
            System.out.println("5. Recomendar Livros por Tema");
            System.out.println("6. Buscar livro");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine(); // consumir a nova linha

            switch (opcao) {
                // Aqui o usuário pode adicionar um novo livro à lista
                case 1:
                    System.out.print("Título: ");
                    String titulo = scanner.nextLine();
                    System.out.print("Autor: ");
                    String autor = scanner.nextLine();
                    System.out.print("Ano de Publicação: ");
                    int ano = scanner.nextInt();
                    scanner.nextLine(); // consumir a nova linha
                    System.out.print("Tema: ");
                    String tema = scanner.nextLine();
                    Livro livro = new Livro(titulo, autor, ano, tema);
                    listaLivros.adicionar(livro);
                    arvoreTemas.inserir(livro); // Insere na árvore por tema
                    break;
                // O usuário pode listar todos os livros cadastrados no sistema
                case 2:
                    if (listaLivros.isEmpty()) {
                        System.out.println("Nenhum livro cadastrado.");
                    } else {
                        listaLivros.listarLivros();
                    }
                break;
                // O usuário pode ordenar os livros por título utilizando Bubble Sort
                case 3:
                    if (listaLivros.isEmpty()) {
                        System.out.println("Nenhum livro cadastrado para ordenar por título.");
                    } else {
                        listaLivros.ordenarPorTitulo();
                    }
                break;
                // O usuário pode ordenar os livros por autor utilizando Bubble Sort
                case 4:
                    if (listaLivros.isEmpty()) {
                        System.out.println("Nenhum livro cadastrado para ordenar por autor.");
                    } else {
                        listaLivros.ordenarPorAutor();
                    }
                break;
                // Recomendar livros com base em um tema específico utilizando a árvore binária
                case 5:
                    if (listaLivros.isEmpty()) {
                        System.out.println("Nenhum livro cadastrado para recomendação.");
                    } else {
                        System.out.print("Escolha um tema para recomendações: ");
                        String temaEscolhido = scanner.nextLine();
                        arvoreTemas.recomendarPorTema(temaEscolhido);
                    }
                break;
                // Buscar um livro por título, autor ou tema
                case 6:
                    if (listaLivros.isEmpty()) {
                        System.out.println("Nenhum livro cadastrado para buscar.");
                    } else {
                        System.out.print("Digite o título, autor ou tema do livro que deseja buscar: ");
                        String criterio = scanner.nextLine();
                        listaLivros.buscarLivro(criterio);
                    }
                break;
                case 0:
                    System.out.println("Saindo...");
                    break;
                default:
                    System.out.println("Opção inválida!");
            }
        } while (opcao != 0);
        scanner.close();
    }
}

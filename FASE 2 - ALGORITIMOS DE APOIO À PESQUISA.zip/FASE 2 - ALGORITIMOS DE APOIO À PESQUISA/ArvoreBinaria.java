class ArvoreBinaria {
    No raiz;
    public boolean isEmpty() {
        return raiz == null;  // A árvore está vazia se a raiz for nula
    }

    public void inserir(Livro livro) {
        raiz = inserirRecursivo(raiz, livro);
    }

    // Método recursivo para inserir um livro na árvore binária
    private No inserirRecursivo(No raiz, Livro livro) {
        if (raiz == null) {
            raiz = new No(livro); // Se o nó for vazio, insere o livro aqui
            return raiz;
        }
    // Comparação para determinar se o livro será inserido à esquerda ou direita
        if (livro.tema.compareTo(raiz.livro.tema) < 0) {
            raiz.esquerda = inserirRecursivo(raiz.esquerda, livro); // Insere à esquerda se o tema for "menor"
        } else if (livro.tema.compareTo(raiz.livro.tema) > 0) {
            raiz.direita = inserirRecursivo(raiz.direita, livro); // Insere à direita se o tema for "maior"
        }
        return raiz;
    }

    public void recomendarPorTema(String tema) {
    if (isEmpty()) {
        System.out.println("Nenhum livro cadastrado para recomendação.");
        return;
    }
        System.out.println("Livros recomendados para o tema '" + tema + "':");
        recomendarPorTemaRecursivo(raiz, tema);
    }

// Método recursivo que percorre a árvore binária e recomenda livros do tema escolhido
    private void recomendarPorTemaRecursivo(No raiz, String tema) {
        if (raiz != null) {
            recomendarPorTemaRecursivo(raiz.esquerda, tema); // Percorre a subárvore esquerda
            // Exibe o livro se o tema corresponder
            if (raiz.livro.tema.equalsIgnoreCase(tema)) {
                System.out.println(raiz.livro);
            }
            recomendarPorTemaRecursivo(raiz.direita, tema); // Percorre a subárvore direita
        }
    }
}

public class Livro {
    String titulo;
    String autor;
    int ano; // este campo deve corresponder ao que você está tentando acessar
    String tema;

    public Livro(String titulo, String autor, int ano, String tema) {
        this.titulo = titulo;
        this.autor = autor;
        this.ano = ano; // Certifique-se de que o nome do campo aqui é o mesmo usado em outros lugares
        this.tema = tema;
    }

    @Override
    public String toString() {
        return "Título: " + titulo + ", Autor: " + autor + ", Ano: " + ano + ", Tema: " + tema;
    }
}
